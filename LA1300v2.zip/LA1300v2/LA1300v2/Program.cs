﻿using System;

namespace NumberGuessingGame
{
    class Program
    {
        static Random rng = new Random();
        static int highScore = int.MaxValue;

        static void Main(string[] args)
        {
            Console.WriteLine("Willkommen zum Zahlenraten!");
            do
            {
                PlayGame();
                Console.WriteLine("Möchten Sie erneut spielen? (y/n)");
            }
            while (Console.ReadLine().ToLower() == "y");
        }

        static void PlayGame()
        {
            int secretNumber = rng.Next(1, 101);
            int attempts = 0;
            int guessedNumber;

            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("Erraten Sie die Geheimzahl zwischen 1 und 100!");
            Console.ResetColor();

            do
            {
                Console.WriteLine("Geben Sie eine Zahl ein:");
                while (!int.TryParse(Console.ReadLine(), out guessedNumber) || guessedNumber < 1 || guessedNumber > 100)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Ungültige Eingabe. Bitte geben Sie eine Zahl zwischen 1 und 100 ein:");
                    Console.Beep(500, 500); 
                    Console.ResetColor();
                }

                attempts++;

                if (guessedNumber < secretNumber)
                {
                    Console.ForegroundColor = ConsoleColor.Blue;
                    Console.WriteLine("Die gesuchte Zahl ist grösser!");
                    Console.Beep(400, 300);  
                    Console.ResetColor();
                }
                else if (guessedNumber > secretNumber)
                {
                    Console.ForegroundColor = ConsoleColor.Blue;
                    Console.WriteLine("Die gesuchte Zahl ist kleiner!");
                    Console.Beep(600, 300);  
                    Console.ResetColor();
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine($"Gratulation! Sie haben die Zahl {secretNumber} in {attempts} Versuchen erraten!");
                    Console.Beep(800, 200); 
                    Console.Beep(1000, 200);
                    if (attempts < highScore)
                    {
                        highScore = attempts;
                        Console.WriteLine("Neuer Highscore!");
                    }
                    Console.ResetColor();
                }
            }
            while (guessedNumber != secretNumber);

            Console.WriteLine($"Der aktuelle Highscore beträgt: {highScore} Versuche.");
        }
    }
}
